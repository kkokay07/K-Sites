"""
Report Generator for K-Sites

This module generates publication-ready HTML reports from K-Sites pipeline output.
"""

import json
import html
from typing import Dict, Any
import logging

# Set up logging
logger = logging.getLogger(__name__)


def generate_html_report(pipeline_output: dict, output_path: str) -> None:
    """
    Generate a publication-ready HTML report from pipeline output.
    
    Args:
        pipeline_output: Output dictionary from run_k_sites_pipeline
        output_path: Path to save the HTML report
    """
    logger.info(f"Generating HTML report at {output_path}")
    
    try:
        # Extract data from pipeline output
        metadata = pipeline_output.get("metadata", {})
        genes = pipeline_output.get("genes", [])
        
        # Count statistics
        total_genes_screened = len(genes)
        total_guides = sum(len(gene.get("guides", [])) for gene in genes)
        pathway_conflict_guides = sum(
            1 for gene in genes 
            for guide in gene.get("guides", []) 
            if guide.get("pathway_conflict", False)
        )
        
        # Generate the HTML report
        html_content = _generate_report_html(
            metadata, 
            genes, 
            total_genes_screened, 
            total_guides, 
            pathway_conflict_guides
        )
        
        # Write to file
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Successfully generated HTML report at {output_path}")
        
    except Exception as e:
        logger.error(f"Failed to generate HTML report: {str(e)}")
        raise


def _generate_report_html(
    metadata: Dict[str, Any], 
    genes: list, 
    total_genes_screened: int, 
    total_guides: int, 
    pathway_conflict_guides: int
) -> str:
    """
    Generate the complete HTML report.
    """
    # Escape metadata values for safety
    escaped_go_term = html.escape(metadata.get("go_term", "Unknown"))
    escaped_organism = html.escape(metadata.get("organism", "Unknown"))
    resolved_organism = metadata.get("resolved_organism", {})
    escaped_scientific_name = html.escape(resolved_organism.get("scientific_name", "Unknown"))
    timestamp = metadata.get("timestamp", "")
    
    # Build the HTML content
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>K-Sites CRISPR Design Report - {escaped_go_term}</title>
    <style>
        :root {{
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #2c3e50;
            --border-color: #dee2e6;
            --text-color: #212529;
            --text-light: #6c757d;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: white;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        
        header {{
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border-color);
        }}
        
        h1 {{
            color: var(--primary-color);
            margin-bottom: 10px;
            font-size: 2.2em;
        }}
        
        .subtitle {{
            color: var(--text-light);
            font-size: 1.1em;
            margin-bottom: 15px;
        }}
        
        .summary-card {{
            background: linear-gradient(135deg, #f5f7fa 0%, #e4edf9 100%);
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-left: 4px solid var(--secondary-color);
        }}
        
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 15px;
        }}
        
        .summary-item {{
            text-align: center;
            padding: 15px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }}
        
        .summary-value {{
            font-size: 1.8em;
            font-weight: bold;
            color: var(--primary-color);
        }}
        
        .summary-label {{
            font-size: 0.9em;
            color: var(--text-light);
        }}
        
        .section {{
            margin: 30px 0;
        }}
        
        .section-title {{
            color: var(--primary-color);
            border-bottom: 2px solid var(--secondary-color);
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 1.5em;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }}
        
        th, td {{
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }}
        
        th {{
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
        }}
        
        tr:nth-child(even) {{
            background-color: #f8f9fa;
        }}
        
        tr:hover {{
            background-color: #e9f7fe;
        }}
        
        .sequence {{
            font-family: 'SF Mono', Consolas, Monaco, monospace;
            font-size: 0.9em;
            letter-spacing: 0.5px;
            background-color: #f8f9fa;
            padding: 2px 6px;
            border-radius: 4px;
            border: 1px solid #e9ecef;
        }}
        
        .score-high {{
            color: var(--success-color);
            font-weight: bold;
        }}
        
        .score-medium {{
            color: var(--warning-color);
            font-weight: bold;
        }}
        
        .score-low {{
            color: var(--danger-color);
            font-weight: bold;
        }}
        
        .pathway-conflict {{
            background-color: #fff3cd;
            color: #856404;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: bold;
        }}
        
        .btn-copy {{
            background-color: #e9ecef;
            border: none;
            padding: 4px 8px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8em;
        }}
        
        .btn-copy:hover {{
            background-color: #dee2e6;
        }}
        
        .accordion {{
            background-color: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            margin-bottom: 10px;
            overflow: hidden;
        }}
        
        .accordion-header {{
            background-color: #f8f9fa;
            padding: 15px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
        }}
        
        .accordion-content {{
            padding: 0;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.2s ease-out;
        }}
        
        .accordion.active .accordion-content {{
            max-height: 1000px;
        }}
        
        .accordion-body {{
            padding: 20px;
        }}
        
        .bio-context {{
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
            border-left: 4px solid var(--secondary-color);
        }}
        
        .abstract {{
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px dashed var(--border-color);
        }}
        
        .abstract:last-child {{
            border-bottom: none;
        }}
        
        .abstract-title {{
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--primary-color);
        }}
        
        .abstract-meta {{
            font-size: 0.85em;
            color: var(--text-light);
            margin-bottom: 8px;
        }}
        
        .download-section {{
            text-align: center;
            margin: 40px 0;
            padding: 30px;
            background: linear-gradient(135deg, #e8f4f8 0%, #d4edf9 100%);
            border-radius: 10px;
        }}
        
        .download-btn {{
            display: inline-block;
            background-color: var(--secondary-color);
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1.1em;
            margin-top: 15px;
            transition: background-color 0.3s;
        }}
        
        .download-btn:hover {{
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }}
        
        @media (max-width: 768px) {{
            body {{
                padding: 10px;
            }}
            
            .summary-grid {{
                grid-template-columns: 1fr;
            }}
            
            th, td {{
                padding: 8px 10px;
                font-size: 0.9em;
            }}
            
            .sequence {{
                font-size: 0.8em;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>K-Sites CRISPR Design Report</h1>
            <div class="subtitle">GO Term: {escaped_go_term} | Organism: {escaped_scientific_name} | Generated: {timestamp}</div>
        </header>
        
        <div class="summary-card">
            <h2>Executive Summary</h2>
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="summary-value">{total_genes_screened}</div>
                    <div class="summary-label">Genes Screened</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">{total_guides}</div>
                    <div class="summary-label">gRNAs Designed</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">{len([g for gene in genes for g in gene.get('guides', []) if g.get('doench_score', 0) >= 0.7])}</div>
                    <div class="summary-label">High-Efficacy gRNAs</div>
                </div>
                <div class="summary-item">
                    <div class="summary-value">{pathway_conflict_guides}</div>
                    <div class="summary-label">Pathway Conflicts</div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <h2 class="section-title">Gene Summary</h2>
            <table>
                <thead>
                    <tr>
                        <th>Gene Symbol</th>
                        <th>Pleiotropy Score</th>
                        <th>Description</th>
                        <th>gRNAs Available</th>
                    </tr>
                </thead>
                <tbody>
"""
    
    # Add gene rows to the table
    for gene in genes:
        symbol = html.escape(gene.get("symbol", "Unknown"))
        score = gene.get("pleiotropy_score", 0)
        description = html.escape(gene.get("description", ""))
        guide_count = len(gene.get("guides", []))
        
        html_content += f"""
                    <tr>
                        <td><strong>{symbol}</strong></td>
                        <td>{score}</td>
                        <td>{description}</td>
                        <td>{guide_count}</td>
                    </tr>
"""
    
    html_content += """
                </tbody>
            </table>
        </div>
        
        <div class="section">
            <h2 class="section-title">Detailed gRNA Designs</h2>
"""
    
    # Add detailed gRNA information for each gene
    for gene in genes:
        symbol = html.escape(gene.get("symbol", "Unknown"))
        guides = gene.get("guides", [])
        
        if not guides:
            continue
            
        html_content += f"""
            <div class="accordion">
                <div class="accordion-header" onclick="toggleAccordion(this)">
                    {symbol} - {len(guides)} gRNA{'s' if len(guides) != 1 else ''}
                    <span>▼</span>
                </div>
                <div class="accordion-content">
                    <div class="accordion-body">
                        <table>
                            <thead>
                                <tr>
                                    <th>gRNA Sequence (5'→3')</th>
                                    <th>Position</th>
                                    <th>Doench Score</th>
                                    <th>CFD Off-targets</th>
                                    <th>Pathway Conflict</th>
                                    <th>Copy Sequence</th>
                                </tr>
                            </thead>
                            <tbody>
"""
        
        for guide in guides:
            seq = html.escape(guide.get("seq", ""))
            position = guide.get("position", "N/A")
            doench_score = guide.get("doench_score", 0)
            cfd_off_targets = guide.get("cfd_off_targets", "N/A")
            pathway_conflict = guide.get("pathway_conflict", False)
            
            # Determine score class for coloring
            if doench_score >= 0.7:
                score_class = "score-high"
            elif doench_score >= 0.5:
                score_class = "score-medium"
            else:
                score_class = "score-low"
            
            # Format pathway conflict indicator
            if pathway_conflict:
                conflict_indicator = '<span class="pathway-conflict">⚠️ Yes</span>'
            else:
                conflict_indicator = "No"
            
            html_content += f"""
                                <tr>
                                    <td><span class="sequence">{seq}</span></td>
                                    <td>{position}</td>
                                    <td class="{score_class}">{doench_score:.2f}</td>
                                    <td>{cfd_off_targets}</td>
                                    <td>{conflict_indicator}</td>
                                    <td><button class="btn-copy" onclick="copyToClipboard('{seq}')">📋 Copy</button></td>
                                </tr>
"""
        
        html_content += """
                            </tbody>
                        </table>
"""
        
        # Add biological context section
        html_content += f"""
                        <div class="bio-context">
                            <h3>Biological Context for {symbol}</h3>
"""
        
        # This would normally include data from literature_context.py
        # For now, we'll include placeholder content
        html_content += """
                            <p><em>Biological context information would appear here based on literature and pathway analysis.</em></p>
                        </div>
                    </div>
                </div>
            </div>
"""
    
    html_content += """
        </div>
        
        <div class="download-section">
            <h2>Download Full Results</h2>
            <p>Download a CSV file containing all gRNA designs with complete metadata for further analysis.</p>
            <a href="#" class="download-btn" onclick="downloadCSV()">Download CSV Report</a>
        </div>
        
        <footer style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid var(--border-color); color: var(--text-light); font-size: 0.9em;">
            <p>K-Sites CRISPR Design Platform | Generated by Universal K-Sites Pipeline</p>
            <p>This report contains publication-ready gRNA designs with pathway-aware off-target filtering.</p>
        </footer>
    </div>
    
    <script>
        function toggleAccordion(header) {
            const accordion = header.parentElement;
            accordion.classList.toggle('active');
            const arrow = header.querySelector('span');
            arrow.textContent = accordion.classList.contains('active') ? '▲' : '▼';
        }
        
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Copied to clipboard: ' + text);
            }).catch(function(err) {
                console.error('Could not copy text: ', err);
                // Fallback for older browsers
                const textArea = document.createElement('textarea');
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                    alert('Copied to clipboard: ' + text);
                } catch (err) {
                    console.error('Fallback copy failed', err);
                }
                document.body.removeChild(textArea);
            });
        }
        
        function downloadCSV() {
            // This would generate a real CSV in a complete implementation
            alert('CSV download would occur here with the complete dataset');
        }
        
        // Initialize accordions to be closed by default
        document.addEventListener('DOMContentLoaded', function() {
            const accordions = document.querySelectorAll('.accordion');
            accordions.forEach(acc => acc.classList.remove('active'));
        });
    </script>
</body>
</html>"""
    
    return html_content