"""
Literature Context Module for K-Sites RAG System

This module enriches gRNA reports with biological context from literature and protein databases.
"""

import logging
import time
import requests
from typing import List, Dict, Optional
from Bio import Entrez
import random

# Set up logging
logger = logging.getLogger(__name__)

# Set email for Entrez (required by NCBI)
Entrez.email = "kkokay07@gmail.com"


class LiteratureContextError(Exception):
    """Raised when literature context retrieval fails."""
    pass


def get_pubmed_abstracts(gene_symbol: str, organism_taxid: str, max_results: int = 5) -> List[Dict]:
    """
    Query PubMed E-Utils for abstracts related to a gene and organism.
    
    Args:
        gene_symbol: Gene symbol to search for
        organism_taxid: NCBI Taxonomy ID for the organism
        max_results: Maximum number of abstracts to return (default: 5)
        
    Returns:
        List of dictionaries with PubMed abstract information:
        [
            {
                "pmid": "...",
                "title": "...",
                "abstract": "...",
                "year": ...
            },
            ...
        ]
    """
    try:
        # Map taxid to organism name for search
        organism_name = _taxid_to_organism_name(organism_taxid)
        
        # Build search term
        search_term = f"{gene_symbol}[Gene] AND {organism_name}[Organism]"
        
        # Search PubMed
        handle = Entrez.esearch(db="pubmed", term=search_term, retmax=max_results)
        search_results = Entrez.read(handle)
        handle.close()
        
        id_list = search_results.get("IdList", [])
        
        if not id_list:
            logger.info(f"No PubMed results found for {gene_symbol} in {organism_name}")
            return []
        
        # Fetch abstracts
        id_list = id_list[:max_results]  # Limit to max_results
        handle = Entrez.efetch(db="pubmed", id=id_list, retmode="xml")
        records = Entrez.read(handle)
        handle.close()
        
        abstracts = []
        for article in records["PubmedArticle"]:
            medline_citation = article["MedlineCitation"]
            
            pmid = str(medline_citation["PMID"])
            
            # Extract title
            article_title = ""
            if "ArticleTitle" in medline_citation["Article"]:
                article_title = str(medline_citation["Article"]["ArticleTitle"])
            
            # Extract abstract
            abstract_text = ""
            if "Abstract" in medline_citation["Article"]:
                if "AbstractText" in medline_citation["Article"]["Abstract"]:
                    abstract_parts = medline_citation["Article"]["Abstract"]["AbstractText"]
                    if isinstance(abstract_parts, list):
                        abstract_text = " ".join([str(part) for part in abstract_parts])
                    else:
                        abstract_text = str(abstract_parts)
            
            # Extract year
            year = None
            if "Journal" in medline_citation["Article"]:
                if "JournalIssue" in medline_citation["Article"]["Journal"]:
                    if "PubDate" in medline_citation["Article"]["Journal"]["JournalIssue"]:
                        pub_date = medline_citation["Article"]["Journal"]["JournalIssue"]["PubDate"]
                        if "Year" in pub_date:
                            year = int(pub_date["Year"])
                        elif "MedlineDate" in pub_date:
                            # Extract year from MedlineDate (format may vary)
                            import re
                            year_match = re.search(r'\d{4}', str(pub_date["MedlineDate"]))
                            if year_match:
                                year = int(year_match.group(0))
            
            abstract_info = {
                "pmid": pmid,
                "title": article_title,
                "abstract": abstract_text,
                "year": year
            }
            
            abstracts.append(abstract_info)
        
        logger.info(f"Retrieved {len(abstracts)} PubMed abstracts for {gene_symbol}")
        return abstracts
        
    except Exception as e:
        logger.warning(f"Failed to retrieve PubMed abstracts for {gene_symbol}: {str(e)}")
        return []


def get_uniprot_info(gene_symbol: str, organism_taxid: str) -> Dict:
    """
    Fetch UniProt entry for a gene via REST API.
    
    Args:
        gene_symbol: Gene symbol to search for
        organism_taxid: NCBI Taxonomy ID for the organism
        
    Returns:
        Dictionary with UniProt information:
        {
            "protein_name": "...",
            "domains": [...],
            "ptms": [...],
            "subcellular_location": "...",
            "function": "..."
        }
    """
    try:
        # Map taxid to organism name for UniProt search
        organism_name = _taxid_to_organism_name(organism_taxid).lower().replace(" ", "_")
        
        # Build query for UniProt
        query = f"{gene_symbol}[gene] AND {organism_taxid}[taxonomy]"
        
        # Request parameters
        params = {
            "query": query,
            "format": "json",
            "size": 1  # Only get the first result
        }
        
        # Make request to UniProt
        response = requests.get("https://rest.uniprot.org/uniprotkb/search", params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        if not data.get("results"):
            logger.info(f"No UniProt entry found for {gene_symbol} in organism {organism_taxid}")
            return {}
        
        # Extract the first result
        result = data["results"][0]
        uniprot_entry = result.get("entry", result)  # Handle different response formats
        
        # Extract relevant information
        protein_name = ""
        if "protein" in uniprot_entry:
            if "recommendedName" in uniprot_entry["protein"]:
                if "fullName" in uniprot_entry["protein"]["recommendedName"]:
                    protein_name = uniprot_entry["protein"]["recommendedName"]["fullName"]["value"]
        
        # Extract domains (Pfam)
        domains = []
        if "features" in uniprot_entry:
            for feature in uniprot_entry["features"]:
                if feature.get("type") == "DOMAIN":
                    domain_info = {
                        "name": feature.get("description", "Unknown"),
                        "start": feature.get("location", {}).get("begin", {}).get("value"),
                        "end": feature.get("location", {}).get("end", {}).get("value")
                    }
                    domains.append(domain_info)
        
        # Extract PTMs
        ptms = []
        if "features" in uniprot_entry:
            for feature in uniprot_entry["features"]:
                if feature.get("type") in ["MOD_RES", "LIPID", "CARBOHYD"]:
                    ptm_info = {
                        "type": feature.get("type"),
                        "description": feature.get("description", ""),
                        "location": feature.get("location", {}).get("begin", {}).get("value")
                    }
                    ptms.append(ptm_info)
        
        # Extract subcellular location
        subcellular_locations = []
        if "comments" in uniprot_entry:
            for comment in uniprot_entry["comments"]:
                if comment.get("commentType") == "SUBCELLULAR_LOCATION":
                    if "subcellularLocations" in comment:
                        for location in comment["subcellularLocations"]:
                            if "location" in location:
                                subcellular_locations.append(location["location"]["value"])
        
        # Extract function
        function = ""
        if "comments" in uniprot_entry:
            for comment in uniprot_entry["comments"]:
                if comment.get("commentType") == "FUNCTION":
                    if "texts" in comment:
                        for text in comment["texts"]:
                            if "value" in text:
                                function = text["value"]
                                break
        
        uniprot_info = {
            "protein_name": protein_name,
            "domains": domains,
            "ptms": ptms,
            "subcellular_location": "; ".join(subcellular_locations) if subcellular_locations else "",
            "function": function
        }
        
        logger.info(f"Retrieved UniProt info for {gene_symbol}")
        return uniprot_info
        
    except Exception as e:
        logger.warning(f"Failed to retrieve UniProt info for {gene_symbol}: {str(e)}")
        return {}


def get_pathway_literature(gene_symbol: str, organism_taxid: str) -> List[str]:
    """
    Get literature context for pathway partners of a gene.
    
    Args:
        gene_symbol: Gene symbol to find pathway partners for
        organism_taxid: NCBI Taxonomy ID for the organism
        
    Returns:
        List of abstract texts from pathway partner literature
    """
    try:
        # Try to get pathway neighbors using Neo4j
        from k_sites.neo4j.graph_client import get_pathway_neighbors
        
        pathway_neighbors = get_pathway_neighbors(gene_symbol, organism_taxid)
        
        if not pathway_neighbors:
            logger.info(f"No pathway neighbors found for {gene_symbol}")
            return []
        
        # Get top 3 pathway partners
        top_partners = pathway_neighbors[:3]
        
        pathway_abstracts = []
        for partner in top_partners:
            try:
                # Get abstracts for each pathway partner
                partner_abstracts = get_pubmed_abstracts(partner, organism_taxid, max_results=2)
                
                for abstract in partner_abstracts:
                    if abstract.get("abstract"):
                        pathway_abstracts.append(abstract["abstract"])
                
            except Exception as e:
                logger.warning(f"Could not get literature for pathway partner {partner}: {str(e)}")
                continue
        
        logger.info(f"Retrieved literature for {len(top_partners)} pathway partners of {gene_symbol}")
        return pathway_abstracts
        
    except ImportError:
        logger.warning("Neo4j graph client not available, skipping pathway literature retrieval")
        return []
    except Exception as e:
        logger.warning(f"Failed to retrieve pathway literature for {gene_symbol}: {str(e)}")
        return []


def _taxid_to_organism_name(taxid: str) -> str:
    """
    Convert NCBI TaxID to organism name.
    
    Args:
        taxid: NCBI Taxonomy ID
        
    Returns:
        Organism name
    """
    taxid_mapping = {
        "9606": "Homo sapiens",
        "10090": "Mus musculus", 
        "10116": "Rattus norvegicus",
        "7227": "Drosophila melanogaster",
        "6239": "Caenorhabditis elegans",
        "7955": "Danio rerio",
        "4932": "Saccharomyces cerevisiae",
        "3702": "Arabidopsis thaliana",
        "39947": "Sus scrofa",
        "9913": "Bos taurus",
        "hsa": "Homo sapiens",
        "mmu": "Mus musculus",
        "rno": "Rattus norvegicus",
        "dme": "Drosophila melanogaster",
        "cel": "Caenorhabditis elegans",
        "dre": "Danio rerio",
        "sce": "Saccharomyces cerevisiae",
        "ath": "Arabidopsis thaliana"
    }
    
    return taxid_mapping.get(taxid, "organism")


def enrich_gene_context(gene_symbol: str, organism_taxid: str) -> Dict:
    """
    Get all literature context for a gene.
    
    Args:
        gene_symbol: Gene symbol to enrich
        organism_taxid: NCBI Taxonomy ID for the organism
        
    Returns:
        Dictionary with all literature context
    """
    context = {}
    
    # Get PubMed abstracts
    try:
        context["pubmed_abstracts"] = get_pubmed_abstracts(gene_symbol, organism_taxid)
    except Exception as e:
        logger.warning(f"Could not get PubMed abstracts for {gene_symbol}: {str(e)}")
        context["pubmed_abstracts"] = []
    
    # Get UniProt information
    try:
        context["uniprot_info"] = get_uniprot_info(gene_symbol, organism_taxid)
    except Exception as e:
        logger.warning(f"Could not get UniProt info for {gene_symbol}: {str(e)}")
        context["uniprot_info"] = {}
    
    # Get pathway literature
    try:
        context["pathway_literature"] = get_pathway_literature(gene_symbol, organism_taxid)
    except Exception as e:
        logger.warning(f"Could not get pathway literature for {gene_symbol}: {str(e)}")
        context["pathway_literature"] = []
    
    return context