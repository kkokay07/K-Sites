"""
GO-Gene Mapper for K-Sites

This module retrieves genes associated with a specific GO term for a given organism
using the NCBI EUtils API.
"""

import logging
import requests
import os
from typing import List, Dict, Optional
from pathlib import Path
import json
import time
import urllib.parse

# Set up logging
logger = logging.getLogger(__name__)


class GoTermNotFoundError(Exception):
    """Raised when a GO term is not found."""
    pass


class GeneRetrievalError(Exception):
    """Raised when gene retrieval fails."""
    pass


def get_genes_for_go_term(go_term: str, taxid: str) -> List[Dict[str, str]]:
    """
    Retrieve genes associated with a specific GO term for a given organism.
    
    Args:
        go_term: GO term identifier (e.g., "GO:0006281")
        taxid: NCBI Taxonomy ID (e.g., "9606" for human)
        
    Returns:
        List of dictionaries containing gene information:
        [
            {
                "symbol": "BRCA1", 
                "entrez_id": "672", 
                "description": "BRCA1 DNA repair associated"
            },
            ...
        ]
        
    Raises:
        GoTermNotFoundError: If the GO term is not found
        GeneRetrievalError: If gene retrieval fails
    """
    logger.info(f"Fetching genes for GO term {go_term} in organism {taxid}")
    
    # Validate GO term format
    if not _validate_go_term(go_term):
        raise ValueError(f"Invalid GO term format: {go_term}. Expected format: GO:0000000")
    
    try:
        # Use NCBI EUtils to search for genes associated with the GO term
        # Since NCBI doesn't have direct GO term search in esummary, we'll search for 
        # genes in the taxid that are related to processes described by the GO term
        
        base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        
        # Map GO term to relevant keywords for search
        go_keywords = _get_go_term_keywords(go_term)
        search_term = f"{taxid}[Taxonomy ID]"
        
        # Add keywords to search term
        if go_keywords:
            search_term += f" AND ({' OR '.join(go_keywords)})"
        
        # Search for genes in the specified taxid with keywords related to the GO term
        search_url = base_url + "esearch.fcgi"
        search_params = {
            "db": "gene",
            "term": search_term,
            "retmax": 100,  # Limit to 100 genes for initial test
            "retmode": "json",
            "usehistory": "y"  # Use history to enable esummary
        }
        
        # Add API key and email if available
        if "NCBI_EMAIL" in os.environ:
            search_params["email"] = os.environ["NCBI_EMAIL"]
        if "NCBI_API_KEY" in os.environ:
            search_params["api_key"] = os.environ["NCBI_API_KEY"]
        
        # Make the search request
        response = requests.get(search_url, params=search_params, timeout=30)
        response.raise_for_status()
        
        search_data = response.json()
        
        if "esearchresult" not in search_data:
            raise GeneRetrievalError(f"Invalid response from NCBI ESearch for GO term {go_term}")
        
        id_list = search_data["esearchresult"].get("idlist", [])
        
        if not id_list:
            logger.warning(f"No genes found for GO term {go_term} in organism {taxid} using keyword search")
            # Try a broader search with just the taxonomy ID
            search_params["term"] = f"{taxid}[Taxonomy ID]"
            response = requests.get(search_url, params=search_params, timeout=30)
            response.raise_for_status()
            
            search_data = response.json()
            id_list = search_data["esearchresult"].get("idlist", [])
        
        if not id_list:
            logger.warning(f"No genes retrieved for GO term {go_term} in organism {taxid}")
            return []
        
        # Get detailed information for each gene with rate limiting
        import time
        
        genes = []
        # Process genes in smaller batches to avoid rate limiting
        batch_size = 20
        for i in range(0, len(id_list[:50]), batch_size):
            batch_ids = id_list[i:i + batch_size]
            
            summary_url = base_url + "esummary.fcgi"
            summary_params = {
                "db": "gene",
                "id": ",".join(batch_ids),
                "retmode": "json"
            }
            
            if "NCBI_EMAIL" in os.environ:
                summary_params["email"] = os.environ["NCBI_EMAIL"]
            if "NCBI_API_KEY" in os.environ:
                summary_params["api_key"] = os.environ["NCBI_API_KEY"]
            
            summary_response = requests.get(summary_url, params=summary_params, timeout=30)
            summary_response.raise_for_status()
            
            summary_data = summary_response.json()
            
            if "result" in summary_data:
                result = summary_data["result"]
                # Remove special keys that aren't gene IDs
                gene_keys = [key for key in result.keys() if key not in ["uids"]]
                
                for gene_id in gene_keys:
                    gene_info = result.get(gene_id, {})
                    symbol = gene_info.get("name", "unknown")
                    description = gene_info.get("description", "")
                    
                    if symbol and symbol.lower() != "unknown":
                        genes.append({
                            "symbol": symbol,
                            "entrez_id": gene_id,
                            "description": description
                        })
            
            # Add delay between batches to respect rate limits
            time.sleep(0.5)
        
        summary_data = summary_response.json()
        
        genes = []
        if "result" in summary_data:
            result = summary_data["result"]
            # Remove special keys that aren't gene IDs
            gene_keys = [key for key in result.keys() if key not in ["uids"]]
            
            for gene_id in gene_keys:
                gene_info = result.get(gene_id, {})
                symbol = gene_info.get("name", "unknown")
                description = gene_info.get("description", "")
                
                if symbol and symbol.lower() != "unknown":
                    genes.append({
                        "symbol": symbol,
                        "entrez_id": gene_id,
                        "description": description
                    })
        
        logger.info(f"Retrieved {len(genes)} genes for GO term {go_term} in organism {taxid}")
        return genes
        
    except requests.RequestException as e:
        logger.error(f"Request failed for GO term {go_term} in organism {taxid}: {str(e)}")
        raise GeneRetrievalError(f"Failed to retrieve genes for GO term {go_term} in organism {taxid}: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error retrieving genes for GO term {go_term} in organism {taxid}: {str(e)}")
        raise GeneRetrievalError(f"Unexpected error retrieving genes for GO term {go_term} in organism {taxid}: {str(e)}")


def _get_go_term_keywords(go_term: str) -> List[str]:
    """
    Get relevant keywords for searching a GO term.
    
    Args:
        go_term: GO term identifier
        
    Returns:
        List of keywords for search
    """
    go_keyword_map = {
        "GO:0006281": ["DNA repair", "nucleotide-excision repair", "NER"],
        "GO:0006974": ["cellular response to DNA damage stimulus", "DNA damage response"],
        "GO:0006259": ["DNA metabolic process", "DNA metabolism"],
        "GO:0006260": ["DNA replication", "replication"],
        "GO:0006289": ["nucleotide-excision repair", "NER", "DNA repair"],
        "GO:0006298": ["mismatch repair", "MMR", "DNA repair"],
        "GO:0006302": ["double-strand break processing", "DSB", "DNA break"],
        "GO:0006303": ["double-strand break repair", "DSB", "DNA repair"],
        "GO:0006308": ["DNA catabolic process", "DNA degradation"],
        "GO:0006310": ["DNA recombination", "recombination"],
        "GO:0006464": ["cellular protein modification process", "protein modification"],
        "GO:0006950": ["response to stress", "stress response"],
        "GO:0006979": ["response to oxidative stress", "oxidative stress"]
    }
    
    return go_keyword_map.get(go_term, [])


def _validate_go_term(go_term: str) -> bool:
    """
    Validate the format of a GO term.
    
    Args:
        go_term: GO term to validate
        
    Returns:
        True if valid, False otherwise
    """
    import re
    pattern = r'^GO:\d{7}$'
    return bool(re.match(pattern, go_term.upper()))