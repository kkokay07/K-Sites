"""
Pleiotropy Scoring Module for K-Sites

This module computes a biologically grounded pleiotropy score by combining:
1. GO-based pleiotropy: count of non-target Biological Process (BP) terms
2. Pathway-based pleiotropy: number of KEGG pathways the gene participates in
"""

import logging
from typing import List, Dict, Tuple
from enum import Enum

# Set up logging
logger = logging.getLogger(__name__)


class GeneNotFoundError(Exception):
    """Exception raised when a gene is not found in NCBI or graph database."""
    pass


def score_pleiotropy(gene_symbol: str, organism_taxid: str, target_go_term: str) -> int:
    """
    Compute a biologically grounded pleiotropy score by combining GO-based
    and pathway-based pleiotropy measures.

    Args:
        gene_symbol: Gene symbol to score
        organism_taxid: NCBI Taxonomy ID for the organism
        target_go_term: Target GO term to exclude from counting

    Returns:
        Integer pleiotropy score calculated as:
        (GO_BP_count - 1) + (KEGG_pathway_degree)
        Where -1 accounts for excluding the target GO term itself

    Raises:
        GeneNotFoundError: If gene is not found in NCBI or graph database
    """
    # Validate GO term format
    if not _validate_go_term(target_go_term):
        raise ValueError(f"Invalid GO term format: {target_go_term}")

    # First, validate that the gene exists
    if not _validate_gene_exists(gene_symbol, organism_taxid):
        raise GeneNotFoundError(f"Gene {gene_symbol} not found in organism {organism_taxid}")

    # Get GO-based pleiotropy (non-target BP terms)
    go_bp_count = _get_go_biological_process_count(gene_symbol, organism_taxid, target_go_term)
    
    # Get pathway-based pleiotropy (KEGG pathway degree)
    try:
        kegg_pathway_count = _get_kegg_pathway_count(gene_symbol, organism_taxid)
    except Exception as e:
        logger.warning(f"Could not retrieve KEGG pathway data for {gene_symbol} in {organism_taxid}, falling back to GO-only scoring: {str(e)}")
        kegg_pathway_count = 0

    # Calculate combined pleiotropy score
    pleiotropy_score = (go_bp_count - 1) + kegg_pathway_count  # Subtract 1 to exclude target GO term
    
    logger.debug(f"Pleiotropy score for {gene_symbol}: GO_BP_count={go_bp_count}, KEGG_pathways={kegg_pathway_count}, Final_score={pleiotropy_score}")
    
    return pleiotropy_score


def _validate_go_term(go_term: str) -> bool:
    """
    Validate the format of a GO term.
    
    Args:
        go_term: GO term to validate
        
    Returns:
        True if valid, False otherwise
    """
    import re
    pattern = r'^GO:\d{7}$'
    return bool(re.match(pattern, go_term.upper()))


def _validate_gene_exists(gene_symbol: str, organism_taxid: str) -> bool:
    """
    Validate that a gene exists in NCBI for the given organism.
    
    Args:
        gene_symbol: Gene symbol to validate
        organism_taxid: NCBI Taxonomy ID for the organism
        
    Returns:
        True if gene exists, False otherwise
    """
    try:
        # Use NCBI E-utilities to validate gene
        import requests
        base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
        params = {
            "db": "gene",
            "term": f"{gene_symbol}[Gene Name] AND {organism_taxid}[Organism]",
            "retmax": 1,
            "retmode": "json"
        }
        
        response = requests.get(base_url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        if "esearchresult" in data and "idlist" in data["esearchresult"]:
            id_list = data["esearchresult"]["idlist"]
            return len(id_list) > 0
        
        return False
    except Exception as e:
        logger.warning(f"Could not validate gene {gene_symbol} in organism {organism_taxid}: {str(e)}")
        return False


def _get_go_biological_process_count(gene_symbol: str, organism_taxid: str, target_go_term: str) -> int:
    """
    Get the count of Biological Process GO terms associated with a gene,
    excluding the target GO term.
    
    Args:
        gene_symbol: Gene symbol to analyze
        organism_taxid: NCBI Taxonomy ID for the organism
        target_go_term: Target GO term to exclude from counting
        
    Returns:
        Count of non-target Biological Process GO terms
    """
    try:
        # Import here to avoid circular dependencies
        from k_sites.data_retrieval.quickgo_client import get_gene_go_annotations
        
        # Get GO annotations for the gene
        go_annotations = get_gene_go_annotations(gene_symbol, organism_taxid)
        
        # Filter for Biological Process terms and exclude target term
        bp_terms = [
            ann for ann in go_annotations
            if ann.aspect == 'biological_process' and ann.go_id != target_go_term
        ]
        
        logger.debug(f"Found {len(bp_terms)} non-target BP terms for {gene_symbol}")
        return len(bp_terms)
        
    except ImportError:
        # Fallback if quickgo_client is not implemented yet
        logger.warning("quickgo_client not available, using mock GO BP count")
        # This is a simplified fallback - in practice, implement proper GO lookup
        return _mock_get_go_biological_process_count(gene_symbol, organism_taxid, target_go_term)
    except Exception as e:
        logger.warning(f"Could not retrieve GO annotations for {gene_symbol}: {str(e)}")
        return 0


def _mock_get_go_biological_process_count(gene_symbol: str, organism_taxid: str, target_go_term: str) -> int:
    """
    Mock implementation of GO BP count retrieval.
    This should be replaced with actual QuickGO API calls.
    """
    # In a real implementation, this would call the QuickGO API
    # For now, we'll simulate the process
    import random
    
    # Simulate retrieving GO terms (this is just for demonstration)
    # In reality, you would use the QuickGO REST API
    simulated_bp_count = random.randint(1, 10)  # Random number for demo purposes
    logger.debug(f"Mock: Returning {simulated_bp_count} BP terms for {gene_symbol}")
    return simulated_bp_count


def _get_kegg_pathway_count(gene_symbol: str, organism_taxid: str) -> int:
    """
    Get the count of KEGG pathways the gene participates in.
    
    Args:
        gene_symbol: Gene symbol to analyze
        organism_taxid: NCBI Taxonomy ID for the organism
        
    Returns:
        Count of KEGG pathways the gene participates in
    """
    try:
        # Import the graph client
        from k_sites.neo4j.graph_client import get_pathway_neighbors
        
        # Get pathway neighbors which implies the gene's pathway participation
        # In the Neo4j graph, we can count the number of pathways a gene is connected to
        # by querying the pathways associated with this gene
        
        # First, resolve the gene symbol to a format compatible with Neo4j
        resolved_gene = _resolve_gene_for_neo4j(gene_symbol, organism_taxid)
        
        # Now we need to get the actual pathway count for this gene
        # This requires a direct query to count the number of pathways the gene is in
        pathway_count = _get_gene_pathway_count_from_graph(resolved_gene, organism_taxid)
        
        logger.debug(f"Gene {gene_symbol} participates in {pathway_count} KEGG pathways")
        return pathway_count
        
    except ImportError:
        logger.warning("graph_client not available, returning 0 for KEGG pathway count")
        return 0
    except Exception as e:
        logger.warning(f"Could not retrieve KEGG pathway data for {gene_symbol}: {str(e)}")
        return 0


def _resolve_gene_for_neo4j(gene_symbol: str, organism_taxid: str) -> str:
    """
    Resolve gene symbol to the format expected by the Neo4j database.
    
    Args:
        gene_symbol: Gene symbol to resolve
        organism_taxid: NCBI Taxonomy ID for the organism
        
    Returns:
        Resolved gene identifier for Neo4j
    """
    # Map NCBI TaxID to KEGG organism code
    kegg_org_code = _map_taxid_to_kegg(organism_taxid)
    
    if kegg_org_code:
        # Format for KEGG: {organism_code}:{gene_symbol}
        return f"{kegg_org_code}:{gene_symbol}"
    
    # If we can't map to KEGG code, return the original gene symbol
    return gene_symbol


def _map_taxid_to_kegg(taxid: str) -> str:
    """
    Map NCBI TaxID to KEGG organism code.
    
    Args:
        taxid: NCBI Taxonomy ID
        
    Returns:
        KEGG organism code
    """
    # Common mappings from NCBI TaxID to KEGG organism codes
    taxid_to_kegg = {
        "9606": "hsa",  # Homo sapiens
        "10090": "mmu",  # Mus musculus
        "10116": "rno",  # Rattus norvegicus
        "7227": "dme",   # Drosophila melanogaster
        "6239": "cel",   # Caenorhabditis elegans
        "7955": "dre",   # Danio rerio
        "4932": "sce",   # Saccharomyces cerevisiae
        "3702": "ath",   # Arabidopsis thaliana
    }
    
    return taxid_to_kegg.get(taxid, "")


def _get_gene_pathway_count_from_graph(gene_id: str, organism_taxid: str) -> int:
    """
    Direct query to count the number of pathways a gene participates in.
    
    Args:
        gene_id: Gene ID in Neo4j format
        organism_taxid: NCBI Taxonomy ID for the organism
        
    Returns:
        Count of pathways the gene participates in
    """
    try:
        from k_sites.neo4j.graph_client import get_graph_client
        
        client = get_graph_client()
        
        # Query to count the number of pathways a gene is involved in
        query = """
        MATCH (o:Organism {id: $organism_taxid})-[:HAS_PATHWAY]->(p:Pathway)<-[:HAS_GENE]-(g:Gene)
        WHERE g.id = $gene_id OR g.original_name = $gene_id
        RETURN count(DISTINCT p) AS pathway_count
        """
        
        # Try to map organism taxid to KEGG code for Neo4j query
        kegg_org_code = _map_taxid_to_kegg(organism_taxid)
        if kegg_org_code:
            # The organism in Neo4j might be stored as the KEGG code
            query = """
            MATCH (o:Organism {id: $organism_code})-[:HAS_PATHWAY]->(p:Pathway)<-[:HAS_GENE]-(g:Gene)
            WHERE g.id = $gene_id OR g.original_name = $gene_id
            RETURN count(DISTINCT p) AS pathway_count
            """
            params = {"organism_code": kegg_org_code, "gene_id": gene_id}
        else:
            params = {"organism_taxid": organism_taxid, "gene_id": gene_id}
        
        results = client._run_query_with_retry(query, params)
        
        if results and len(results) > 0:
            return results[0]["pathway_count"]
        
        return 0
        
    except Exception as e:
        logger.warning(f"Could not query pathway count from graph for gene {gene_id}: {str(e)}")
        return 0